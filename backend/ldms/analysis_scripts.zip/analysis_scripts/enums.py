import enum
from django.utils.translation import gettext as _

class LCEnum(enum.Enum):
	"""Enumeration for different land covers
	"""
	WATER = 1
	BARELAND = 2
	ARTIFICIAL = 3
	WETLAND = 4
	CROPLAND = 5
	GRASSLAND = 6
	FOREST = 7


class LulcCalcEnum(enum.Enum):
	"""
	Enumeration for different types of LULC computations
	"""
	LULC = 0
	LULC_CHANGE = 1

class ForestChangeEnum(enum.Enum):
	"""
	Enumeration for different types of Forest Change computations
	"""
	FOREST_LOSS = 0
	FOREST_GAIN = 1

class LulcChangeEnum(enum.Enum):
	"""
	Enumeration for different types of LULC change
	"""
	DEGRADED = (2, _("Degradation"))
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Improvement"))

	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class SOCChangeEnum(enum.Enum):
	"""
	Enumeration for different types of SOC change
	"""
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Potential Improvement"))
	DEGRADED = (2, _("Potential Degradation"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]


class ClimaticRegionEnum(enum.Enum):
	"""
	Enumeration for the different climatic conditions.
	Manages Land Use coefficients when computing SOC
	"""
	TemperateDry = (1, 0.8)
	TemperateMoist = (2, 0.69)
	TropicalDry = (3, 0.58)
	TropicalMoist = (4, 0.48)
	TropicalMontane = (5, 0.64)

	@property
	def id(self):
		"""
		Return the unique id for SOC computation
		"""
		return self.value[0]
	
	@property
	def coeff(self):
		"""
		Return the coefficient value for SOC computation
		"""
		return self.default_f
		# return self.value[1]
	
	@property
	def default_f(self):
		"""
		Return default f where climatic region is unknown
		"""
		return 0.6

class TrajectoryChangeEnum(enum.Enum):
	"""
	Enumeration for different types of SOC change
	"""
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Potential Improvement"))
	DEGRADED = (2, _("Potential Degradation"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class StateChangeEnum(enum.Enum):
	"""
	Enumeration for different types of Productivity State change
	"""
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Potential Improvement"))
	DEGRADED = (2, _("Potential Degradation"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class PerformanceChangeEnum(enum.Enum):
	"""
	Enumeration for different types of Productivity Performance change
	"""
	STABLE = (0, _("Stable"))
	DEGRADED = (2, _("Potential Degradation"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class ProductivityChangeEnum(enum.Enum):
	"""
	Enumeration for different types of Overall Productivity change
	"""
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Improvement"))
	DEGRADED = (2, _("Degradation"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]


class BinaryLandDegradationChangeEnum(enum.Enum):
	"""
	Enumeration for binary types of LandDegradation change (Degraded and Not-degraded)
	"""
	IMPROVED = (1, _("Not degraded"))
	DEGRADED = (2, _("Degraded"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class LandDegradationChangeEnum(enum.Enum):
	"""
	Enumeration for different types of LandDegradation change
	"""
	STABLE = (0, _("Stable"))
	IMPROVED = (1, _("Not degraded"))
	DEGRADED = (2, _("Degraded"))

	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class AridityIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Aridity Index Change
	"""
	HYPER_ARID = (1, _("Hyper-arid"))
	ARID = (2, _("Arid"))
	SEMI_ARID = (3, _("Semi-arid"))
	DRY_SUBHUMID = (4, _("Dry sub-humid"))
	MOIST_SUBHUMID = (5, _("Moist sub-humid"))
	HUMID = (6, _("Humid"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class ClimateQualityIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Climate Quality Index
	"""
	HIGH_QUALITY = (1, _("High Quality"))
	MODERATE_QUALITY = (2, _("Moderate Quality"))
	LOW_QUALITY = (3, _("Low Quality"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class SoilQualityIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Soil Quality Index
	"""
	HIGH_QUALITY = (1, _("High Quality"))
	MODERATE_QUALITY = (2, _("Moderate Quality"))
	LOW_QUALITY = (3, _("Low Quality"))
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

class SoilSlopeIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Soil Slope
	"""
	VERY_GENTLE_TO_FLAT = (1, _("Very gentle to flat"), 1)
	GENTLE = (2, _("Gentle"), 1.2)
	STEEP = (3, _("Steep"), 1.5)
	VERY_STEEP = (4, _("Very steep"), 2)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]

class SoilDepthIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Soil Depth
	"""
	DEEP = (1, _("Deep"), 1)
	MODERATE = (2, _("Moderate"), 2)
	SHALLOW = (3, _("Shallow"), 3)
	VERY_SHALLOW = (4, _("Very shallow"), 4)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]

class SoilDrainageIndexEnum(enum.Enum):
	"""
	Enumeration for different types of Soil Drainage
	"""
	WELL_DRAINED = (1, _("Well drained"), 1)
	IMPERFECTLY_DRAINED = (2, _("Imperfectly drained"), 1.2)
	POORLY_DRAINED = (3, _("Poorly drained"), 2)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]
class SoilParentMaterialEnum(enum.Enum):
	"""
	Enumeration for different types of Parent Material
	"""
	GOOD = (1, _("Good"), 1.0)
	MODERATE = (2, _("Moderate"), 1.7)
	POOR = (3, _("Poor"), 2.0)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]

class SoilTextureEnum(enum.Enum):
	"""
	Enumeration for different types of Soil Texture
	"""
	GOOD = (1, _("L, SCL, SL, LS, CL"), 1)
	MODERATE = (2, _("SC, SiL SiCL"), 1.2)
	POOR = (3, _("Si, C, SiC"), 1.6)
	VERY_POOR = (4, _("S"), 2)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]

class SoilRockFragmentEnum(enum.Enum):
	"""
	Enumeration for different types of Rock Fragments
	"""
	VERY_STONY = (1, _("Very stony"), 1)
	STONY = (2, _("Stony"), 1.3)
	BARE_TO_SLIGHTLY_STONY = (3, _("Bare to slightly stony"), 2)
	
	@property
	def key(self):
		return self.value[0]

	@property
	def label(self):
		return self.value[1]

	@property
	def index(self):
		return self.value[2]

class ProductivityCalcEnum(enum.Enum):
	"""
	Enumeration for different types of Productivity computations
	"""
	TRAJECTORY = 0
	STATE = 1
	PERFORMANCE = 2
	PRODUCTIVITY = 3

class MedalusCalcEnum(enum.Enum):
	"""
	Enumeration for different types of Medalus computations
	"""
	ARIDITY_INDEX = 1
	CLIMATE_QUALITY_INDEX = 2
	SOIL_QUALITY_INDEX = 3

class RasterSourceEnum(enum.Enum):
	"""
	Enumeration for different raster sources
	"""
	LULC = "LULC"
	MODIS = "Modis"
	LANDSAT7 = "Landsat 7"
	LANDSAT8 = "Landsat 8"
	HANSEN = "Hansen"
	SENTINEL2 = "Sentinel 2"
	# SINGLE_BAND_IMAGE = 1
	# MODIS = 2
	# LANDSAT7 = 3
	# LANDSAT8 = 4

class GenericRasterBandEnum(enum.Enum):
	"""
	Enumeration for raster bands independently of image source.
	Will be used to retrieve the correct band dynamically
	depending on the image source
	"""
	HAS_SINGLE_BAND = 0 # handles reading of images with only a single band
	RED = 1
	GREEN = 2
	BLUE = 3
	NIR = 4
	SWIR1 = 5
	SWIR2 = 6

class MODISBandEnum(enum.Enum):
	"""
	Enumeration for MODIS bands
	"""
	RED = 1
	NIR = 2
	BLUE = 3
	GREEN = 4
	SWIR1 = 5
	SWIR2 = 6

class Landsat7BandEnum(enum.Enum):
	"""
	Enumeration for Landsat 7 bands
	"""
	BLUE = 1
	GREEN = 2
	RED = 3
	NIR = 4
	SWIR1 = 5
	TIR = 6
	SWIR2 = 7
	PANCHROMATIC = 8

class Landsat8BandEnum(enum.Enum):
	"""
	Enumeration for Landsat 8 bands
	"""
	COASTAL = 1
	BLUE = 2
	GREEN = 3
	RED = 4
	NIR = 5
	SWIR1 = 6
	SWIR2 = 7
	PANCHROMATIC = 8
	CIRRUS = 9
	TIR1 = 10
	TIR2 = 11

class RasterOperationEnum(enum.Enum):
	"""Enumeration for different raster operations
	"""
	ADD = 1
	SUBTRACT = 2
	DIVIDE = 3
	MULTIPLY = 4

class RasterCategoryEnum(enum.Enum):
	"""Enumeration for different raster categories
	"""
	NDVI = "NDVI"
	LULC = "LULC"
	SOC = "SOC"
	RAINFALL = "Rainfall"
	ASPECT = "Aspect"
	FOREST_LOSS = "Forest Loss"
	SAVI = "SAVI"
	MSAVI = "MSAVI"
	EVAPOTRANSPIRATION = "Evapotranspiration"
	ECOLOGICAL_UNITS = "Ecological Units"
	SOIL_SLOPE = "Soil Slope"
	SOIL_DEPTH = "Soil Depth"
	SOIL_DRAINAGE = "Soil Drainage"
	SOIL_PARENT_MATERIAL = "Soil Parent Material"
	SOIL_TEXTURE = "Soil Texture"
	SOIL_ROCK_FRAGMENT = "Soil Rock Fragments"