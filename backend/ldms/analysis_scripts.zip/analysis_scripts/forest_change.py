
from django.utils.translation import gettext as _
from ldms.analysis.lulc import LULC
from ldms.enums import RasterSourceEnum
import ee
from ldms.models import Raster
from ldms.utils.vector_util import get_vector
from ldms.analysis.gee import GEE
from ldms.enums import (ForestChangeEnum, ForestChangeEnum, LCEnum, GenericRasterBandEnum,
	 RasterSourceEnum, RasterCategoryEnum)
from ldms.utils.common_util import cint, flt, return_with_error, validate_years
from ldms.utils.file_util import get_absolute_media_path, get_download_url, get_media_dir, file_exists
from ldms.utils.raster_util import (get_raster_values, get_raster_object, 
								save_raster, get_raster_meta, reproject_raster,
								extract_pixels_using_vector, clip_raster_to_vector,
								return_raster_with_stats)
from ldms.utils.raster_util import RasterCalcHelper
from django.conf import settings
import numpy as np

class ForestChangeSettings:
	SUB_DIR = "" # "forestloss" # Subdirectory to store rasters for forestloss
	RASTER_BASE_YEAR = 2000

class ForestChange:
	"""
	Wrapper class for calculating ForestChange
	"""	

	def __init__(self, **kwargs):
		"""
		Args:
			**admin_level (int)**: 
				The administrative level for the polygon to be used in case a shapefile id has been provided for the parameter **vector**.
			**shapefile_id (int)**: 
				ID of an existing shapefile. 
			**custom_coords (GeoJSON, or GEOSGeometry)**: 
				Coordinates which may be as a result of a custom drawn polygon or a Geometry object in form of GeoJSON.
			**raster_type (int)**:  
				The type of raster files to be used
			**start_year (int)**: 
				Starting year for which raster files should be used. 
			**end_year (int)**: 
				End year for which raster files should be used. 
			**end_year (int)**: 
				End year for which raster files should be used. 
			**transform (string)**:
				Either of:
					- "area"
					- a string with placeholder e.g x * x to mean square of that value
			**request (Request)**: 
				A Web request object
		""" 
		self.admin_level = kwargs.get('admin_level', None)
		self.shapefile_id = kwargs.get('shapefile_id', None)
		self.custom_vector_coords = kwargs.get('custom_vector_coords', None)
		self.raster_type = kwargs.get('raster_type', None)
		self.start_year = kwargs.get('start_year', None)
		self.end_year = kwargs.get('end_year', None)
		self.analysis_year = kwargs.get('end_year', None)
		self.transform = kwargs.get('transform', "area")
		self.request = kwargs.get('request', None)
		self.error = None
		self.analysis_type = None #one of LULC or LULC_CHANGE
		self.raster_source = kwargs.get('raster_source', RasterSourceEnum.LULC)
		self.enforce_single_year = True
		
		self.lulc = LULC(
			admin_level=self.admin_level,
			shapefile_id = self.shapefile_id,
			custom_vector_coords = self.custom_vector_coords,
			raster_type = self.raster_type,
			start_year=self.start_year,
			end_year=self.end_year,
			transform=self.transform,
			raster_source=self.raster_source,
			enforce_single_year=False,
			request=self.request,
		)

	def calculate_forest_change(self):	
		if self.raster_source == RasterSourceEnum.HANSEN:
			return self.calculate_loss_based_on_hansen()
		return self.calculate_change_based_on_lulc()		

	def calculate_change_based_on_lulc(self):
		"""Compute Forest Change by getting the LULC values for Forest cover"""
		res = self.lulc.calculate_lulc()
		self.error = self.lulc.error
		return res

	def calculate_loss_based_on_hansen(self):
		"""
		Compute Forest Change using local hansen data
		
		Returns:
			[Response]: [A JSON string with statistic values]
		"""    
		if not self.analysis_year:
			self.analysis_year = cint(self.end_year)

		self.analysis_type = ForestChangeEnum.FOREST_LOSS
		"""Default the year to ForestChangeSettings.RASTER_BASE_YEAR because Hansen
		is a single raster containing values for all the years. 
		See https://gitlab.com/locateit/oss-land-degradation-monitoring-service/oss-ldms/-/issues/22
		"""
		
		self.start_year = ForestChangeSettings.RASTER_BASE_YEAR # self.start_year
		self.end_year = ForestChangeSettings.RASTER_BASE_YEAR # self.end_year
		start_year = self.start_year
		end_year = self.end_year

		vector_id = self.shapefile_id
		admin_level = self.admin_level
		raster_type = self.raster_type
				
		custom_coords = self.custom_vector_coords
		transform = self.transform
		
		"""
		- If user has drawn custom polygon, ignore the vector id
		since the custom polygon could span several shapefiles.
		- If no custom polygon is selected, demand an admin_level 
		and the vector id
		"""
		vector, error = get_vector(admin_level=self.admin_level, shapefile_id=self.shapefile_id, 
						custom_vector_coords=self.custom_vector_coords, admin_0=None,
						request=self.request)
		if error:
			return self.return_with_error(error)

		# Validate that a raster type has been selected
		raster_type = cint(raster_type)
		if not raster_type:
			return self.return_with_error(_("No raster type has been selected"))

		"""
		Validate analysis periods
		"""
		start_year, end_year, period_error = self.validate_periods()
		if period_error:
			return self.return_with_error(period_error)

		if self.enforce_single_year:
			if start_year != end_year:
				return self.return_with_error(_("Forest change can only be analysed for a single period"))

		if cint(self.analysis_year) < ForestChangeSettings.RASTER_BASE_YEAR:
			return self.return_with_error(_("Forest change can only be analysed from year {0} onwards".format(ForestChangeSettings.RASTER_BASE_YEAR)))

		# Get Raster Models	by period and raster type
		# Do not filter by year since Hansen is a single raster with pixel values being the years
		raster_models = Raster.objects.filter(
						raster_category=RasterCategoryEnum.FOREST_LOSS.value,
						raster_source=self.raster_source.value,
						raster_year=ForestChangeSettings.RASTER_BASE_YEAR
						#raster_year__gte=start_year, 
						#raster_year__lte=end_year
					)

		if not raster_models:
			return self.return_with_error(_("No matching rasters"))

		if self.enforce_single_year:
			if len(raster_models) > 1:
				return self.return_with_error(_("Multiple Hansen rasters exist for the selected period"))

		lulc_raster_path = None
		for raster_model in raster_models:			
			# for raster_model in raster_models:
			raster_path = get_media_dir() + raster_model.rasterfile.name

			# Validate existence of the raster file
			if not file_exists(raster_path):
				return self.return_with_error(_("Raster %s does not exist" % (raster_model.rasterfile.name)))

			if raster_model.raster_year == start_year:
				lulc_raster, lulc_raster_path = clip_raster_to_vector(raster_model.rasterfile.name, vector)
			
		if not lulc_raster_path:
			return self.return_with_error(_("No matching raster for year %s" % (start_year)))

		hlper = RasterCalcHelper(vector=vector,
					rasters=raster_models,
					raster_type_id=raster_type,
					stats=[],
					is_categorical=True,
					transform=transform)
		res = hlper.get_stats()

		datasource = lulc_raster[0] # since its a (1, width, height) matrix
		
		"""For all the other years, replace their values with nodata value"""
		if self.analysis_year:
			val = flt(self.analysis_year - ForestChangeSettings.RASTER_BASE_YEAR)
			datasource = np.where(datasource != val, settings.DEFAULT_NODATA, datasource)

		return return_raster_with_stats(
			request=self.request,
			datasource=datasource,
			prefix="forestloss", 
			change_enum=ForestChangeEnum, 
			metadata_raster_path=lulc_raster_path, 
			nodata=settings.DEFAULT_NODATA, 
			resolution=raster_model.resolution,
			start_year=start_year,
			end_year=end_year,
			subdir=ForestChangeSettings.SUB_DIR,
			results=res
		)
	
	def return_with_error(self, error):		
		self.error = error
		return return_with_error(self.request, error)
	
	def validate_periods(self):
		"""
		Validate the start and end periods

		Returns:
			tuple (Start_Year, End_Year)
		"""		
		start_year = self.start_year
		end_year = self.end_year

		return validate_years(
							start_year=start_year,
							end_year=end_year,
							both_valid=False)